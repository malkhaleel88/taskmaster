package com.example.taskmaster;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.FileUtils;
import android.util.Log;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.amplifyframework.api.graphql.model.ModelMutation;
import com.amplifyframework.core.Amplify;
import com.amplifyframework.datastore.generated.model.Task;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

public class AddTask extends AppCompatActivity {
    String img="";
    private static final String TAG = "AddTask";
    private String uploadedFileNames;
    ActivityResultLauncher<Intent> someActivityResultLauncher;
    @RequiresApi(api = Build.VERSION_CODES.Q)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        try {
                            onChooseFile(result);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });



        findViewById(R.id.upload).setOnClickListener(view -> {
            Intent chooseFile = new Intent(Intent.ACTION_GET_CONTENT);
            chooseFile.setType("*/*");
            chooseFile = Intent.createChooser(chooseFile, "Choose a file");
            someActivityResultLauncher.launch(chooseFile);
        });



        Button addTaskButton = AddTask.this.findViewById(R.id.button_addTask);
        addTaskButton.setOnClickListener(view -> {
            EditText studentTitle = findViewById(R.id.edit_myTask);
            String TitleName = studentTitle.getText().toString();
            EditText Body = findViewById(R.id.edit_doSomething);
            String BodyB = (Body.getText().toString());
            EditText State = findViewById(R.id.stateinput);
            String StateB = (State.getText().toString());
            RadioButton b1=findViewById(R.id.radioButton1);
            RadioButton b2=findViewById(R.id.radioButton2);
            RadioButton b3=findViewById(R.id.radioButton3);


            String id = null;
            if(b1.isChecked()){
                id="1";
            }
            else if(b2.isChecked()){
                id="2";
            }
            else if(b3.isChecked()){
                id="3";
            }

            dataStore(TitleName, BodyB, StateB,id);

            System.out.println(
                    "++++++++++++++++++++++++++++++++++++++++++++++++++" +
                            " Title Name: " + TitleName
                            +
                            "++++++++++++++++++++++++++++++++++++++++++++++++++"
            );


            Intent intent = new Intent(AddTask.this, MainActivity.class);
            startActivity(intent);
        });

    }

    private void dataStore(String title, String body, String state,String id) {
        String fileNameIfThere = uploadedFileNames == null ? "" : uploadedFileNames;
        Task task = Task.builder().teamId(id).title(title).body(body).state(state).fileName(fileNameIfThere).build();


        Amplify.API.mutate(ModelMutation.create(task), succuess-> {
            Log.i(TAG, "Saved to DYNAMODB");
        }, error -> {
            Log.i(TAG, "error saving to DYNAMODB");
        });

    }


//    @RequiresApi(api = Build.VERSION_CODES.Q)
    private void onChooseFile(ActivityResult activityResult) throws IOException {

        Uri uri = null;
        if (activityResult.getData() != null) {
            uri = activityResult.getData().getData();
        }
        assert uri != null;
        String uploadedFileName = new Date().toString() + "." + getMimeType(getApplicationContext(), uri);

        File uploadFile = new File(getApplicationContext().getFilesDir(), "uploadFile");

        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            FileUtils.copy(inputStream, new FileOutputStream(uploadFile));
        } catch (Exception exception) {
            Log.e("onChooseFile", "onActivityResult: file upload failed" + exception.toString());
        }

        Amplify.Storage.uploadFile(
                uploadedFileName,
                uploadFile,
                success -> Log.i("onChooseFile", "uploadFileToS3: succeeded " + success.getKey()),
                error -> Log.e("onChooseFile", "uploadFileToS3: failed " + error.toString())
        );
        uploadedFileNames= uploadedFileName;
    }
    public static String getMimeType(Context context, Uri uri) {
        String extension;

        if (uri.getScheme().equals(ContentResolver.SCHEME_CONTENT)) {
            final MimeTypeMap mime = MimeTypeMap.getSingleton();
            extension = mime.getExtensionFromMimeType(context.getContentResolver().getType(uri));
        } else {
            extension = MimeTypeMap.getFileExtensionFromUrl(Uri.fromFile(new File(uri.getPath())).toString());

        }

        return extension;
    }

    private boolean permissionGranted(){
        return ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }
    private void requestPermission(){
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
    }
}

//public class AddTask extends AppCompatActivity {
//
//    String fileName = "";
//    private static final String TAG = "AddTask";
//    private String uploadedFileNames;
//    ActivityResultLauncher<Intent> someActivityResultLauncher;
//
//    @RequiresApi(api = Build.VERSION_CODES.Q)
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_add_task);
//
//        ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
//                new ActivityResultContracts.StartActivityForResult(),
//                result -> {
//                    if (result.getResultCode() == Activity.RESULT_OK) {
//                        try {
//                            onChooseFile(result);
//                        } catch (IOException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                });
//
//        findViewById(R.id.btnUploadFile).setOnClickListener(view -> {
//            Intent chooseFile = new Intent(Intent.ACTION_GET_CONTENT);
//            chooseFile.setType("*/*");
//            chooseFile = Intent.createChooser(chooseFile, "Choose a file");
//            someActivityResultLauncher.launch(chooseFile);
//        });
//
////        Button addFile = findViewById(R.id.btnUploadFile);
////        addFile.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View v) {
////
////                getFileFromDevice();
////            }
////        });
//
//        Button submit = findViewById(R.id.button3);
//        submit.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                EditText taskTitle = findViewById(R.id.taskTitleInput);
//                String title = taskTitle.getText().toString();
//
//                EditText taskBody = findViewById(R.id.taskBodyInput);
//                String body = taskBody.getText().toString();
//
//                EditText taskState = findViewById(R.id.taskStateInput);
//                String state = taskState.getText().toString();
//
//                RadioButton b1=findViewById(R.id.radioButtonTeam1);
//                RadioButton b2=findViewById(R.id.radioButtonTeam2);
//                RadioButton b3=findViewById(R.id.radioButtonTeam3);
//
//                String id = null;
//                if(b1.isChecked()){
//                    id="1";
//                }
//                else if(b2.isChecked()){
//                    id="2";
//                }
//                else if(b3.isChecked()){
//                    id="3";
//                }
//
//                dataStore(title, body, state, id);
//
//            }
//        });
//
//        Context context = getApplicationContext();
//        Toast.makeText(context, "Submitted!", Toast.LENGTH_LONG).show();
//
//    }
//
//
//    public void dataStore(String taskTitle, String taskBody, String taskState, String id) {
//        String fileNameIfThere = uploadedFileNames == null ? "" : uploadedFileNames;
//        Task task = Task.builder().teamId(id).title(taskTitle).body(taskBody).state(taskState).fileName(fileNameIfThere).build();
//
//        Amplify.API.mutate(ModelMutation.create(task),
//                success -> Log.i(TAG, "Saved to DynamoDB"),
//                error -> Log.i(TAG, "Error Saving to DynamoDB"));
//
//        Toast toast = Toast.makeText(this, "Task added!", Toast.LENGTH_LONG);
//        toast.show();
//    }
//
//    @RequiresApi(api = Build.VERSION_CODES.Q)
//    private void onChooseFile(ActivityResult activityResult) throws IOException {
//
//        Uri uri = null;
//        if (activityResult.getData() != null) {
//            uri = activityResult.getData().getData();
//        }
//        assert uri != null;
//        String uploadedFileName = new Date().toString() + "." + getMimeType(getApplicationContext(), uri);
//
//        File uploadFile = new File(getApplicationContext().getFilesDir(), "uploadFile");
//
//        try {
//            InputStream inputStream = getContentResolver().openInputStream(uri);
//            FileUtils.copy(inputStream, new FileOutputStream(uploadFile));
//        } catch (Exception exception) {
//            Log.e("onChooseFile", "onActivityResult: file upload failed" + exception.toString());
//        }
//
//        Amplify.Storage.uploadFile(
//                uploadedFileName,
//                uploadFile,
//                success -> Log.i("onChooseFile", "uploadFileToS3: succeeded " + success.getKey()),
//                error -> Log.e("onChooseFile", "uploadFileToS3: failed " + error.toString())
//        );
//        uploadedFileNames= uploadedFileName;
//    }
//    public static String getMimeType(Context context, Uri uri) {
//        String extension;
//
//        if (uri.getScheme().equals(ContentResolver.SCHEME_CONTENT)) {
//            final MimeTypeMap mime = MimeTypeMap.getSingleton();
//            extension = mime.getExtensionFromMimeType(context.getContentResolver().getType(uri));
//        } else {
//            extension = MimeTypeMap.getFileExtensionFromUrl(Uri.fromFile(new File(uri.getPath())).toString());
//
//        }
//
//        return extension;
//    }

//    private boolean permissionGranted(){
//        return ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
//                && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
//    }
//    private void requestPermission(){
//        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
//    }

//    private void getFileFromDevice() {
//        Intent chooseFile = new Intent(Intent.ACTION_GET_CONTENT);
//        chooseFile.setType("*/*");
//        chooseFile = Intent.createChooser(chooseFile, "Choose a File");
//        startActivityForResult(chooseFile, 1234);
//    }
//
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        File uploadFile = new File(getApplicationContext().getFilesDir(), "uploadFileCopied");
//        try {
//            InputStream exampleInputStream = getContentResolver().openInputStream(data.getData());
//            OutputStream outputStream = new FileOutputStream(uploadFile);
//            fileName = data.getData().toString();
//            byte[] buff = new byte[1024];
//            int length;
//            while ((length = exampleInputStream.read(buff)) > 0) {
//                outputStream.write(buff, 0, length);
//            }
//            exampleInputStream.close();
//            outputStream.close();
//            Amplify.Storage.uploadFile(
//                    "image",
//                    uploadFile,
//                    result -> Log.i("MyAmplifyApp", "Successfully uploaded: " + result.getKey()),
//                    storageFailure -> Log.e("MyAmplifyApp", "Upload failed", storageFailure)
//            );
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//}

